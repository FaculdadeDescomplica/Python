from Pessoa2 import Pessoa2
pessoa = Pessoa2("Marcio", 380)


# não consegue puxar protegido
pessoa.__nome
