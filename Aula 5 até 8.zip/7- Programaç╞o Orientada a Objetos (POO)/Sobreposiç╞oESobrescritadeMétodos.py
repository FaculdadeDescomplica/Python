from Pessoa3 import Pessoa3
pessoa3 = Pessoa3("Marcio", 380)


""" pessoa3.adicionar(110, "branca", "0.97x0.97x.097") """
pessoa3.adicionar("P", "preta")

# não existe dentro do python
