class Pessoa:
    nome = ""
    idade = 0

# método = função
    def exibir(self):
        print(self.nome)

# use o valor da própria classe
# use o valor desta mesma classe
# this
