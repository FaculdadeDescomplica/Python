# from Pessoa import Pessoa
# p = Pessoa()
# p.exibir()

from Pessoa import Pessoa
pessoa = Pessoa()
""" print(pessoa.nome)
print(pessoa.idade) """

pessoa.exibir("marcio", 38)
pessoa.exibir("Benedito", 42)
