class Pessoa3:
    __nome = "Marcio"
    idade = 38


# método = função

def adicionar(self, tamanho, cor):
    pass


""" def adicionar(self, voltagem, cor, dimensoes):
    pass """
