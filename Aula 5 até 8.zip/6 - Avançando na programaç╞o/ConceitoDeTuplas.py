""" a = 10
print(a)
a = 11
print(a) """


# tuplas = (1,2,3 ) # imutável! " in tupla" | tupla[0]
# dicionario: sem índice numérico
# CONJUNTOS
# a = {1,2,3}
# b = [1,5,9}
# print(set(a.intersection(b)))
# print(set(a.difference(b))
# # print(set(a.symmetric_fifference(b))) | pertence só a um dos dados
# print(set(b.issubset(a))) | subconjunto

# DESAFIO: pesquisar os métodos naticvos de conjuntos(sets)

a = [1, 2, 3]
a.append(4)
print(a)

tupla = (1, 2, 3, 4, 5, 6, 7, 8, 9, 0)
if 18 in tupla:
    print("existe")
else:
    print("Não existe")
