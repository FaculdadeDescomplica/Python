# tupla = (1, 2, 3, 4, 5, 6, 7, 8, 9, 0)
# if 18 in tupla:
#     print("existe")
# else:
#     print("Não existe")


lista = {"nome": "Marcio", "sobrenome": "Santos"}
print(lista["nome", lista["sobrenome"]])
