# a = 10
# b = 20
# c = 30
# d = 40

# e = a + b
# f = c + d
# g = e + f

# print(g)

print((2 + 3) * 4)  # 20

# Potenciação / Radiciação
# Multiplicação / Divisão
# Adição / Subtração
