# lista = {"nome": "Marcio", "sobrenome": "Santos"}
# print(lista["nome", lista["sobrenome"]])

# tuplas = (1,2,3 ) # imutável! " in tupla" | tupla[0]
# dicionario: sem índice numérico
# CONJUNTOS
# a = {1,2,3}
# b = [1,5,9}
# print(set(a.intersection(b)))
# print(set(a.difference(b))
# # print(set(a.symmetric_fifference(b))) | pertence só a um dos dados
# print(set(b.issubset(a))) | subconjunto

a = {1, 3, 5, 6, 2}
b = {2, 4, 6}
print(set(a.intersection(b)))
