def soma():
    txt = "Imprimindo resultado com variável"
    return txt


print(soma())
