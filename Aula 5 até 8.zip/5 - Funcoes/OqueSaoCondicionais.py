# print(18 % 4)

""" IF/ELSE
Match
Ternários """

""" se chover e for domingo
 saio com guarda-chuva
 senao
  nao saio com guarda-chuva
"""
