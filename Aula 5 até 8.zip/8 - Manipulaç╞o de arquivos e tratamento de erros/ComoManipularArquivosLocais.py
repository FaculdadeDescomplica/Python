conteudo = open("arquivo.txt", "a")
conteudo.write("\nUma linha qualquer \n")
conteudo.write("\nSegunda Linha \n")
conteudo.close()

""" conteudo = open("arquivo.txt", "r")
print(conteudo.read()) """
