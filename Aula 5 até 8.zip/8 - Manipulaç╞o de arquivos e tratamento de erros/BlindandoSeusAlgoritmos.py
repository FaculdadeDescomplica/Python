a = int(input("Digite um Numero = "))
b = int(input("Digite um Outro Numero = "))

if b == 0:
    print("não é possivel dividir nenhum número por zero")
else:
    resultado = a / b
    print(resultado)
