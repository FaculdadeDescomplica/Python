a = 1
while a <= 10:
    print("Teste")
    a = a + 1
