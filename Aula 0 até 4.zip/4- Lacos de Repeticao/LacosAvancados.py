# a = 1
# while a <= 10:
#    print("Teste")
#     a = a + 1

# for a in range(5):
#    print("marcio")

a = ["Marcio", "Larissa", "Benedito", "André"]

# for a in a:
#    print(a)

a = "Descomplica"
for a in a:
    print(a)
