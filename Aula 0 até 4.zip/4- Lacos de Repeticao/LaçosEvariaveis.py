# a = ["Marcio", "Larissa", "Benedito", "André"]

# for a in a:
#    print(a)

a = []
b = 1
print(a)

while b <= 3:
    a.append(input("Digite um nome de aluno: "))
    b = b + 1
print(a)
