# a = []
# b = 1
# print(a)

# while b <= 3:
#    a.append(input("Digite um nome de aluno: "))
#    b = b + 1
# print(a)

a = ["Marcio", "Bruna"]
a.insert(1, "Hellen")
print(a)
a.remove("Marcio")
print(a)
