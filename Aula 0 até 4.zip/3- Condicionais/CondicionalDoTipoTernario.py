# indentação
# print('1') if x == 222 else print('2')


# ternários

idade = int(input("Digite uma idade = "))
print("É MAIOR") if idade >= 18 else print("É MENOR")
