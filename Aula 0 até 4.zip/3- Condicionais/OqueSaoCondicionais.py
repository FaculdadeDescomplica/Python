# print(18 % 4)

# from msvcrt import SEM_NOALIGNMENTFAULTEXCEPT

""" IF/ELSE
match
Ternários """

""" SE CHOVER
SAIO COM GUARDA-CHUVA
SENAO
NAO SAIO COM GUARDA-CHUVA """
