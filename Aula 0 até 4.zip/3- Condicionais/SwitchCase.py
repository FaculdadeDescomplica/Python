# idade = int(input("Digite uma idade = "))
# print("É MAIOR") if idade >= 18 else print("É MENOR")

a = "Marcio"
match a:
    case "Antonio":
        print("Mão é Marcio")
    case "Pedro":
        print("É Pedro e Mão é Marcio")
    case "Marcio":
        print("Achou o Marcio")
        # sobrenome = input("digite seu sobrenome")
