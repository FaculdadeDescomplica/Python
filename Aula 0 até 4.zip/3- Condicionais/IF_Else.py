
# ternarios
# SE CHOVE E FOR DOMINGO
# SAIO COM  GUARDA-CHUVA
# SENA0
# NAO SAIO COM GUARDA-CHUVA

idade = int(input("Digite sua idade: "))

if idade > 18:
    print("É maior de idade")
elif idade == 18:
    print("É Guerreiro Jedi")
else:
    print("É menor de idade")
