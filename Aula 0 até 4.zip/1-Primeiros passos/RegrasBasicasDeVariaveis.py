# 1a regra : Sem Espaços
# 2a regra : não pode começar com números
# 3a regra : não pode ter caracteres especiais
# *-/\|+¨¬ ~ ^
# Comentar
