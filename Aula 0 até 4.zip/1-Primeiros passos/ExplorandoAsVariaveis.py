a = 10
b = "Descomplica"
c = 40.5
print(a)
print(b)
print(c)
