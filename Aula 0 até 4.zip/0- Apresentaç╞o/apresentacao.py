idade = 20
idade = 30
print(idade)
