nome = input("Digite seu nome: ")
nascimento = input("Digite seu ano de nascimento: ")
email = input("Digite seu emai: ")
print("Você ", nome, " nasceu em ", nascimento, " e seu email é ", email)

# print("nascimento : ")
# print(nascimento)
# print("E-mail : ")
# print(email)
