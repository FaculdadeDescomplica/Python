# print("nascimento : ")
# print(nascimento)
# print("E-mail : ")
# print(email)
# a= int(input("Digite um número: "))
# print (a+5)

# 1a Cat: Ariméticos
# # + - * /
# 2a Cat: Relacionais
# # >  <  >=  <=  ==  !=  ===
# 3a Cat: Lógicos
# !
# &&
# ||
MAIORIDADE = 18
idade = int(input("Qual a sua idade?"))
