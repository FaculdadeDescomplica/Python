nome = input("Digite seu nome: ")
nascimento = input("Digite seu ano de nascimento: ")
email = input("Digite seu emai: ")
