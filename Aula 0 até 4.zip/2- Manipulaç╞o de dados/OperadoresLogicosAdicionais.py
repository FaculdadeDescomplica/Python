# potência **
# raiz sqrt()
# modulo

# a= 2
# b = 3
# print(A**b)

# from cmath import sqrt

# qualquer = 25
# print(sqrt(qualquer))

print(18 % 4)
