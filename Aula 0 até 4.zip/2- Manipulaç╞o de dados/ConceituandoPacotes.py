# print(A**b)

# from cmath import sqrt

# qualquer = 25
# print(sqrt(qualquer))

# print(18 % 4)

from math import sqrt

print(sqrt(4))
